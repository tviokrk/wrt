﻿pobrano z http://itporady.pl

obrazki: http://sxc.hu
javascript: http://highslide.com